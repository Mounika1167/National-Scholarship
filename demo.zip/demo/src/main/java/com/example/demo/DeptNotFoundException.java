package com.example.demo;

public class DeptNotFoundException extends Exception {
	DeptNotFoundException(String msg)
	{
		super(msg);
	}

}
